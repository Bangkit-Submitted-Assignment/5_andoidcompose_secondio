package com.dicoding.onepieceapplication.model

data class AtributeChar(
    val id: Long,
    val name: String,
    val photoUrl: String,
    val description: String
)